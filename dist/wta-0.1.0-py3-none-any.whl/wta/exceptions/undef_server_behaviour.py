class UndefinedServerBehaviourError(Exception):
    pass
